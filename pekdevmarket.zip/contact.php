<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/header.php';





// Rediriger si non connecté
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = BASE_URL . '/checkout.php';
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = false;
$orderNumber = '';

// Récupérer les infos utilisateur pour pré-remplir le formulaire
$userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([$user_id]);
$user = $userStmt->fetch();

// Récupérer les articles du panier
$cartStmt = $pdo->prepare("
    SELECT c.id as cart_id, c.quantity, 
           p.id as product_id, p.name, p.slug, p.price, p.stock, p.seller_id,
           pi.image_path
    FROM cart c
    JOIN products p ON c.product_id = p.id
    LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ? AND p.is_active = 1
");
$cartStmt->execute([$user_id]);
$cartItems = $cartStmt->fetchAll();

if (count($cartItems) === 0) {
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

// Calculs
$subtotal = 0;
$totalItems = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
    $totalItems += $item['quantity'];
}

$shippingCost = $subtotal > 100000 ? 0 : 5000;
$total = $subtotal + $shippingCost;

// Traitement de la commande
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données
    $firstName = clean(trim($_POST['first_name'] ?? ''));
    $lastName = clean(trim($_POST['last_name'] ?? ''));
    $phone = clean(trim($_POST['phone'] ?? ''));
    $province = clean(trim($_POST['province'] ?? ''));
    $city = clean(trim($_POST['city'] ?? ''));
    $address = clean(trim($_POST['address'] ?? ''));
    $paymentMethod = clean($_POST['payment_method'] ?? 'cash');
    $notes = clean(trim($_POST['notes'] ?? ''));
    
    // Validation
    if (empty($firstName)) $errors[] = "Le prénom est requis.";
    if (empty($lastName)) $errors[] = "Le nom est requis.";
    if (empty($phone) || strlen($phone) < 8) $errors[] = "Numéro de téléphone invalide.";
    if (empty($province)) $errors[] = "La province est requise.";
    if (empty($city)) $errors[] = "La ville est requise.";
    if (empty($address) || strlen($address) < 10) $errors[] = "L'adresse doit contenir au moins 10 caractères.";
    if (!in_array($paymentMethod, ['cash', 'mobile_money', 'card'])) $errors[] = "Mode de paiement invalide.";
    
    // Vérifier que le panier n'est pas vide et que les produits sont en stock
    foreach ($cartItems as $item) {
        if ($item['quantity'] > $item['stock']) {
            $errors[] = "Stock insuffisant pour : " . $item['name'];
        }
    }
    
    if (count($errors) === 0) {
        try {
            $pdo->beginTransaction();
            
            // Générer un numéro de commande unique
            $orderNumber = 'PKD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
            
            // Créer la commande
            $orderStmt = $pdo->prepare("
                INSERT INTO orders 
                (user_id, order_number, status, payment_method, payment_status, 
                 subtotal, shipping_cost, total, 
                 shipping_first_name, shipping_last_name, shipping_phone, 
                 shipping_province, shipping_city, shipping_address, notes)
                VALUES (?, ?, 'pending', ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $orderStmt->execute([
                $user_id, $orderNumber, $paymentMethod,
                $subtotal, $shippingCost, $total,
                $firstName, $lastName, $phone,
                $province, $city, $address, $notes
            ]);
            
            $orderId = $pdo->lastInsertId();
            
            // Créer les articles de la commande
            $itemStmt = $pdo->prepare("
                INSERT INTO order_items 
                (order_id, product_id, product_name, product_image, quantity, price, total)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($cartItems as $item) {
                $itemTotal = $item['price'] * $item['quantity'];
                $itemStmt->execute([
                    $orderId, 
                    $item['product_id'], 
                    $item['name'], 
                    $item['image_path'],
                    $item['quantity'], 
                    $item['price'], 
                    $itemTotal
                ]);
                
                // Mettre à jour le stock et les ventes du produit
                $pdo->prepare("UPDATE products SET stock = stock - ?, sales_count = sales_count + ? WHERE id = ?")
                    ->execute([$item['quantity'], $item['quantity'], $item['product_id']]);
            }
            
            // Vider le panier
            $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$user_id]);
            
            $pdo->commit();
            $success = true;
            
            // Rediriger vers la page de succès
            header('Location: ' . BASE_URL . '/order-success.php?order=' . $orderNumber);
            exit;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de la création de la commande : " . $e->getMessage();
        }
    }
}

// Récupérer les provinces pour le formulaire
$provincesStmt = $pdo->query("SELECT name FROM provinces ORDER BY name ASC");
$provinces = $provincesStmt->fetchAll();

$pageTitle = 'Finaliser la commande';

?>

<!-- Header -->
<section class="bg-gradient-to-r from-blue-600 to-orange-600 py-8 relative overflow-hidden">
    <div class="absolute inset-0 opacity-10">
        <div class="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></div>
        <div class="absolute bottom-0 right-0 w-60 h-60 bg-white rounded-full translate-x-1/3 translate-y-1/3"></div>
    </div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <nav class="text-sm text-white/80 mb-2">
            <a href="<?= BASE_URL ?>" class="hover:text-white transition">Accueil</a>
            <i class="fas fa-chevron-right text-xs mx-2"></i>
            <a href="<?= BASE_URL ?>/cart.php" class="hover:text-white transition">Panier</a>
            <i class="fas fa-chevron-right text-xs mx-2"></i>
            <span class="text-white font-medium">Commande</span>
        </nav>
        <h1 class="text-2xl md:text-3xl font-bold text-white">Finaliser la commande</h1>
        <p class="text-white/90 text-sm">Étape 2 sur 3 : Informations de livraison</p>
    </div>
</section>

<!-- Progress Steps -->
<section class="bg-white dark:bg-gray-800 border-b dark:border-gray-700">
    <div class="max-w-4xl mx-auto px-4 py-4">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-2 text-blue-600">
                <div class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                    <i class="fas fa-check text-sm"></i>
                </div>
                <span class="text-sm font-semibold hidden sm:inline">Panier</span>
            </div>
            <div class="flex-1 h-1 bg-blue-600 mx-2"></div>
            <div class="flex items-center gap-2 text-blue-600">
                <div class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">2</div>
                <span class="text-sm font-semibold hidden sm:inline">Livraison</span>
            </div>
            <div class="flex-1 h-1 bg-gray-300 dark:bg-gray-600 mx-2"></div>
            <div class="flex items-center gap-2 text-gray-400">
                <div class="w-8 h-8 bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-300 rounded-full flex items-center justify-center font-bold">3</div>
                <span class="text-sm font-semibold hidden sm:inline">Confirmation</span>
            </div>
        </div>
    </div>
</section>

<!-- Main Content -->
<section class="py-8 md:py-12 bg-gray-50 dark:bg-gray-900 min-h-screen">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <?php if (count($errors) > 0): ?>
            <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4 mb-6">
                <h3 class="font-bold text-red-800 dark:text-red-300 mb-2"><i class="fas fa-exclamation-circle mr-2"></i>Erreurs détectées :</h3>
                <ul class="list-disc list-inside text-sm text-red-700 dark:text-red-300 space-y-1">
                    <?php foreach ($errors as $error): ?>
                        <li><?= clean($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="grid lg:grid-cols-3 gap-8">
            
            <!-- Left Column: Forms -->
            <div class="lg:col-span-2 space-y-6">
                
                <!-- Informations personnelles -->
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fas fa-user-circle text-blue-600"></i> Informations personnelles
                    </h2>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Prénom *</label>
                            <input type="text" name="first_name" value="<?= clean($_POST['first_name'] ?? $user['first_name']) ?>" required
                                   class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Nom *</label>
                            <input type="text" name="last_name" value="<?= clean($_POST['last_name'] ?? $user['last_name']) ?>" required
                                   class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Téléphone *</label>
                            <input type="tel" name="phone" value="<?= clean($_POST['phone'] ?? $user['phone']) ?>" required placeholder="+257 79 000 000"
                                   class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                        </div>
                    </div>
                </div>

                <!-- Adresse de livraison -->
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fas fa-map-marker-alt text-orange-500"></i> Adresse de livraison
                    </h2>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Province *</label>
                            <select name="province" required class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                                <option value="">-- Sélectionner --</option>
                                <?php foreach ($provinces as $prov): ?>
                                    <option value="<?= clean($prov['name']) ?>" <?= ($_POST['province'] ?? $user['province']) == $prov['name'] ? 'selected' : '' ?>>
                                        <?= clean($prov['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Ville / Commune *</label>
                            <input type="text" name="city" value="<?= clean($_POST['city'] ?? $user['city']) ?>" required
                                   class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Adresse détaillée *</label>
                            <textarea name="address" rows="3" required placeholder="Quartier, avenue, numéro, point de repère..."
                                      class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"><?= clean($_POST['address'] ?? $user['address']) ?></textarea>
                            <p class="text-xs text-gray-500 mt-1"><i class="fas fa-info-circle mr-1"></i>Minimum 10 caractères pour une livraison précise</p>
                        </div>
                    </div>
                </div>

                <!-- Mode de paiement -->
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fas fa-credit-card text-green-500"></i> Mode de paiement
                    </h2>
                    <div class="grid md:grid-cols-3 gap-3">
                        <label class="relative cursor-pointer">
                            <input type="radio" name="payment_method" value="cash" <?= ($_POST['payment_method'] ?? 'cash') == 'cash' ? 'checked' : '' ?> class="peer sr-only">
                            <div class="border-2 border-gray-200 dark:border-gray-700 rounded-xl p-4 text-center peer-checked:border-blue-600 peer-checked:bg-blue-600/5 transition hover:border-blue-600">
                                <i class="fas fa-money-bill-wave text-3xl text-green-600 mb-2"></i>
                                <p class="font-semibold text-gray-800 dark:text-white">Cash</p>
                                <p class="text-xs text-gray-500">À la livraison</p>
                            </div>
                        </label>
                        
                        <label class="relative cursor-pointer">
                            <input type="radio" name="payment_method" value="mobile_money" <?= ($_POST['payment_method'] ?? '') == 'mobile_money' ? 'checked' : '' ?> class="peer sr-only">
                            <div class="border-2 border-gray-200 dark:border-gray-700 rounded-xl p-4 text-center peer-checked:border-blue-600 peer-checked:bg-blue-600/5 transition hover:border-blue-600">
                                <i class="fas fa-mobile-alt text-3xl text-orange-500 mb-2"></i>
                                <p class="font-semibold text-gray-800 dark:text-white">Mobile Money</p>
                                <p class="text-xs text-gray-500">Lumicash, Ecocash</p>
                            </div>
                        </label>
                        
                        <label class="relative cursor-pointer">
                            <input type="radio" name="payment_method" value="card" <?= ($_POST['payment_method'] ?? '') == 'card' ? 'checked' : '' ?> class="peer sr-only">
                            <div class="border-2 border-gray-200 dark:border-gray-700 rounded-xl p-4 text-center peer-checked:border-blue-600 peer-checked:bg-blue-600/5 transition hover:border-blue-600">
                                <i class="fas fa-credit-card text-3xl text-blue-600 mb-2"></i>
                                <p class="font-semibold text-gray-800 dark:text-white">Carte bancaire</p>
                                <p class="text-xs text-gray-500">Visa, Mastercard</p>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Notes -->
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fas fa-comment-dots text-purple-500"></i> Notes (optionnel)
                    </h2>
                    <textarea name="notes" rows="3" placeholder="Instructions spéciales pour la livraison..."
                              class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"><?= clean($_POST['notes'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Right Column: Order Summary -->
            <div class="lg:col-span-1">
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 sticky top-4 border border-gray-100 dark:border-gray-700">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-4">Résumé</h2>
                    
                    <!-- Items list -->
                    <div class="space-y-3 mb-4 max-h-64 overflow-y-auto pr-2">
                        <?php foreach ($cartItems as $item): ?>
                            <div class="flex gap-3 pb-3 border-b dark:border-gray-700 last:border-0">
                                <img src="<?= $item['image_path'] ?: 'https://via.placeholder.com/60' ?>" 
                                     alt="<?= clean($item['name']) ?>" 
                                     class="w-14 h-14 object-cover rounded-lg flex-shrink-0">
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-semibold text-gray-800 dark:text-white line-clamp-2"><?= clean($item['name']) ?></p>
                                    <p class="text-xs text-gray-500"><?= $item['quantity'] ?> x <?= formatPrice($item['price']) ?></p>
                                </div>
                                <p class="text-sm font-bold text-gray-800 dark:text-white flex-shrink-0"><?= formatPrice($item['price'] * $item['quantity']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Totals -->
                    <div class="space-y-2 pt-4 border-t dark:border-gray-700">
                        <div class="flex justify-between text-sm text-gray-600 dark:text-gray-300">
                            <span>Sous-total (<?= $totalItems ?> articles)</span>
                            <span><?= formatPrice($subtotal) ?></span>
                        </div>
                        <div class="flex justify-between text-sm text-gray-600 dark:text-gray-300">
                            <span>Livraison</span>
                            <span class="<?= $shippingCost == 0 ? 'text-green-500 font-semibold' : '' ?>">
                                <?= $shippingCost == 0 ? 'Gratuite' : formatPrice($shippingCost) ?>
                            </span>
                        </div>
                        <div class="flex justify-between items-center pt-3 border-t dark:border-gray-700">
                            <span class="text-lg font-bold text-gray-800 dark:text-white">Total</span>
                            <span class="text-2xl font-bold text-blue-600"><?= formatPrice($total) ?></span>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <button type="submit" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-800 transition shadow-lg shadow-primary/30 mt-6 flex items-center justify-center gap-2">
                        <i class="fas fa-lock"></i> Confirmer la commande
                    </button>
                    
                    <p class="text-xs text-gray-500 text-center mt-3">
                        <i class="fas fa-shield-alt mr-1"></i> Paiement 100% sécurisé
                    </p>
                    
                    <a href="<?= BASE_URL ?>/cart.php" class="block text-center text-sm text-blue-600 hover:text-orange-500 font-semibold mt-4">
                        <i class="fas fa-arrow-left mr-1"></i> Retour au panier
                    </a>
                </div>
            </div>
        </form>
    </div>
</section>

<?php  ?>