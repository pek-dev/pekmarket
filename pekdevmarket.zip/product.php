<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/header.php';





// Récupérer le slug du produit
$slug = $_GET['slug'] ?? '';

if (!$slug) {
    header('Location: ' . BASE_URL . '/products.php');
    exit;
}

// Traitement de l'ajout d'avis (si soumis)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review']) && isLoggedIn()) {
    $rating = intval($_POST['rating'] ?? 0);
    $title = clean($_POST['title'] ?? '');
    $comment = clean($_POST['comment'] ?? '');
    
    if ($rating >= 1 && $rating <= 5 && !empty($comment)) {
        $reviewStmt = $pdo->prepare("
            INSERT INTO reviews (user_id, product_id, rating, title, comment, is_approved) 
            VALUES (?, ?, ?, ?, ?, 1)
        ");
        $reviewStmt->execute([$_SESSION['user_id'], $product['id'], $rating, $title, $comment]);
        
        // Mettre à jour la note moyenne du produit
        $pdo->prepare("
            UPDATE products 
            SET rating_avg = (SELECT AVG(rating) FROM reviews WHERE product_id = ? AND is_approved = 1),
                rating_count = (SELECT COUNT(*) FROM reviews WHERE product_id = ? AND is_approved = 1)
            WHERE id = ?
        ")->execute([$product['id'], $product['id'], $product['id']]);
        
        header('Location: ' . BASE_URL . '/product.php?slug=' . $slug . '&review_success=1');
        exit;
    }
}

// Récupérer les informations du produit
$productStmt = $pdo->prepare("
    SELECT p.*, 
           c.name as category_name, 
           c.slug as category_slug,
           c.icon as category_icon,
           u.first_name as seller_first, 
           u.last_name as seller_last,
           u.id as seller_id,
           u.avatar as seller_avatar
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN users u ON p.seller_id = u.id
    WHERE p.slug = ? AND p.is_active = 1
");
$productStmt->execute([$slug]);
$product = $productStmt->fetch();

if (!$product) {
    http_response_code(404);
    $pageTitle = 'Produit non trouvé';
    
    echo '<div class="max-w-7xl mx-auto px-4 py-16 text-center">';
    echo '<i class="fas fa-box-open text-6xl text-gray-300 mb-4"></i>';
    echo '<h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-2">Produit non trouvé</h1>';
    echo '<a href="' . BASE_URL . '" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-800 mt-4 inline-block">Retour à l\'accueil</a>';
    echo '</div>';
    
    exit;
}

// Incrémenter les vues
$pdo->prepare("UPDATE products SET views_count = views_count + 1 WHERE id = ?")->execute([$product['id']]);

// Récupérer les images du produit
$imagesStmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, id ASC");
$imagesStmt->execute([$product['id']]);
$images = $imagesStmt->fetchAll();

// Si aucune image, utiliser l'image par défaut
if (count($images) === 0) {
    $images = [['image_path' => 'https://via.placeholder.com/600x600?text=Pas+d\'image']];
}

// Récupérer les avis
$reviewsStmt = $pdo->prepare("
    SELECT r.*, u.first_name, u.last_name, u.avatar
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.product_id = ? AND r.is_approved = 1
    ORDER BY r.created_at DESC
");
$reviewsStmt->execute([$product['id']]);
$reviews = $reviewsStmt->fetchAll();

// Calcul de la répartition des notes
$ratingDistribution = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
foreach ($reviews as $review) {
    if (isset($ratingDistribution[$review['rating']])) {
        $ratingDistribution[$review['rating']]++;
    }
}

// Produits similaires (même catégorie)
$relatedStmt = $pdo->prepare("
    SELECT p.*, c.slug as category_slug
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.category_id = ? AND p.id != ? AND p.is_active = 1
    ORDER BY RAND()
    LIMIT 4
");
$relatedStmt->execute([$product['category_id'], $product['id']]);
$relatedProducts = $relatedStmt->fetchAll();

// Variables pour la page
$discount = calculateDiscount($product['price'], $product['old_price']);
$pageTitle = clean($product['name']) . ' - PekDev Market';
$pageDescription = clean($product['short_description'] ?? $product['name']);
$isFavorite = isLoggedIn() ? isFavorite($_SESSION['user_id'], $product['id'], $pdo) : false;


?>

<!-- Breadcrumbs -->
<section class="bg-gray-50 dark:bg-gray-900 py-4 border-b dark:border-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2 flex-wrap">
            <a href="<?= BASE_URL ?>" class="hover:text-blue-600 transition">Accueil</a>
            <i class="fas fa-chevron-right text-xs"></i>
            <a href="<?= BASE_URL ?>/products.php" class="hover:text-blue-600 transition">Produits</a>
            <i class="fas fa-chevron-right text-xs"></i>
            <a href="<?= BASE_URL ?>/category.php?slug=<?= $product['category_slug'] ?>" class="hover:text-blue-600 transition">
                <?= clean($product['category_name']) ?>
            </a>
            <i class="fas fa-chevron-right text-xs"></i>
            <span class="text-gray-800 dark:text-white font-medium truncate max-w-xs"><?= clean($product['name']) ?></span>
        </nav>
    </div>
</section>

<!-- Main Product Section -->
<section class="py-8 md:py-12 bg-white dark:bg-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-8 lg:gap-12">
            
            <!-- Image Gallery -->
            <div class="space-y-4">
                <div class="relative bg-gray-100 dark:bg-gray-700 rounded-2xl overflow-hidden aspect-square group">
                    <img id="mainImage" src="<?= $images[0]['image_path'] ?>" 
                         alt="<?= clean($product['name']) ?>" 
                         class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                    
                    <?php if ($product['is_new']): ?>
                        <span class="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">Nouveau</span>
                    <?php endif; ?>
                    <?php if ($discount > 0): ?>
                        <span class="absolute top-4 <?= $product['is_new'] ? 'left-28' : 'left-4' ?> bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">-<?= $discount ?>%</span>
                    <?php endif; ?>
                </div>
                
                <!-- Thumbnails -->
                <?php if (count($images) > 1): ?>
                <div class="grid grid-cols-4 gap-3">
                    <?php foreach ($images as $index => $img): ?>
                        <button onclick="changeImage('<?= $img['image_path'] ?>')" 
                                class="aspect-square rounded-lg overflow-hidden border-2 <?= $index === 0 ? 'border-blue-600' : 'border-transparent hover:border-gray-300 dark:hover:border-gray-600' ?> transition thumbnail-btn">
                            <img src="<?= $img['image_path'] ?>" alt="Thumbnail" class="w-full h-full object-cover">
                        </button>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Product Details -->
            <div class="flex flex-col">
                <!-- Header -->
                <div class="mb-6">
                    <a href="<?= BASE_URL ?>/category.php?slug=<?= $product['category_slug'] ?>" 
                       class="inline-flex items-center gap-2 text-sm text-blue-600 hover:text-orange-500 font-medium mb-3">
                        <i class="<?= $product['category_icon'] ?>"></i> <?= clean($product['category_name']) ?>
                    </a>
                    <h1 class="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-800 dark:text-white mb-3 leading-tight">
                        <?= clean($product['name']) ?>
                    </h1>
                    
                    <div class="flex flex-wrap items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-4">
                        <div class="flex items-center gap-1">
                            <?= renderStars($product['rating_avg']) ?>
                            <span class="font-semibold text-gray-800 dark:text-white"><?= number_format($product['rating_avg'], 1) ?></span>
                            <span>(<?= $product['rating_count'] ?> avis)</span>
                        </div>
                        <span class="hidden md:inline">•</span>
                        <span><i class="fas fa-eye mr-1"></i> <?= number_format($product['views_count']) ?> vues</span>
                        <span class="hidden md:inline">•</span>
                        <span><i class="fas fa-shopping-bag mr-1"></i> <?= number_format($product['sales_count']) ?> vendus</span>
                    </div>
                </div>

                <!-- Price -->
                <div class="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 mb-6">
                    <div class="flex items-end gap-3">
                        <span class="text-3xl md:text-4xl font-bold text-blue-600"><?= formatPrice($product['price']) ?></span>
                        <?php if ($product['old_price']): ?>
                            <span class="text-lg text-gray-400 line-through mb-1"><?= formatPrice($product['old_price']) ?></span>
                            <span class="bg-red-100 text-red-600 text-xs font-bold px-2 py-1 rounded mb-1">-<?= $discount ?>%</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        <i class="fas fa-info-circle mr-1"></i> Prix en Francs Burundais (FBu)
                    </p>
                </div>

                <!-- Short Description -->
                <?php if ($product['short_description']): ?>
                <p class="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                    <?= clean($product['short_description']) ?>
                </p>
                <?php endif; ?>

                <!-- Stock & Location -->
                <div class="grid grid-cols-2 gap-4 mb-6">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg <?= $product['stock'] > 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600' ?> flex items-center justify-center">
                            <i class="fas <?= $product['stock'] > 0 ? 'fa-check' : 'fa-times' ?>"></i>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Disponibilité</p>
                            <p class="font-semibold <?= $product['stock'] > 0 ? 'text-green-600' : 'text-red-600' ?>">
                                <?= $product['stock'] > 0 ? 'En stock (' . $product['stock'] . ')' : 'Rupture de stock' ?>
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Localisation</p>
                            <p class="font-semibold text-gray-800 dark:text-white"><?= clean($product['city'] ?? $product['province']) ?></p>
                        </div>
                    </div>
                </div>

                <!-- Actions -->
                <div class="flex flex-col sm:flex-row gap-3 mb-8">
                    <?php if ($product['stock'] > 0): ?>
                        <button onclick="addToCart(<?= $product['id'] ?>)" 
                                class="flex-1 bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-blue-800 transition flex items-center justify-center gap-2 shadow-lg shadow-primary/30">
                            <i class="fas fa-shopping-cart"></i> Ajouter au panier
                        </button>
                        <a href="<?= BASE_URL ?>/checkout.php?product=<?= $product['id'] ?>" 
                           class="flex-1 bg-orange-500 text-white py-3 px-6 rounded-xl font-semibold hover:bg-orange-600 transition flex items-center justify-center gap-2 shadow-lg shadow-secondary/30">
                            <i class="fas fa-bolt"></i> Acheter maintenant
                        </a>
                    <?php else: ?>
                        <button disabled class="flex-1 bg-gray-300 text-gray-500 py-3 px-6 rounded-xl font-semibold cursor-not-allowed flex items-center justify-center gap-2">
                            <i class="fas fa-ban"></i> Indisponible
                        </button>
                    <?php endif; ?>
                    
                    <?php if (isLoggedIn()): ?>
                        <button onclick="toggleFavorite(<?= $product['id'] ?>, this)" 
                                class="w-full sm:w-14 h-14 bg-gray-100 dark:bg-gray-700 rounded-xl flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition">
                            <i class="<?= $isFavorite ? 'fas text-red-500' : 'far' ?> fa-heart text-xl"></i>
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Seller Card -->
                <div class="border dark:border-gray-700 rounded-xl p-4 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <a href="<?= BASE_URL ?>/shop.php?seller=<?= $product['seller_id'] ?>" class="w-12 h-12 bg-gradient-to-br from-blue-600 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                            <?= strtoupper(substr($product['seller_first'], 0, 1) . substr($product['seller_last'], 0, 1)) ?>
                        </a>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Vendu par</p>
                            <a href="<?= BASE_URL ?>/shop.php?seller=<?= $product['seller_id'] ?>" class="font-semibold text-gray-800 dark:text-white hover:text-blue-600 transition">
                                <?= clean($product['seller_first'] . ' ' . $product['seller_last']) ?>
                            </a>
                        </div>
                    </div>
                    <?php if (isLoggedIn() && $_SESSION['user_id'] != $product['seller_id']): ?>
                        <button onclick="contactSeller(<?= $product['seller_id'] ?>)" class="text-blue-600 hover:text-orange-500 text-sm font-semibold flex items-center gap-1">
                            <i class="fas fa-envelope"></i> Contacter
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Description & Reviews Tabs -->
<section class="py-8 md:py-12 bg-gray-50 dark:bg-gray-900">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
            <!-- Tabs Header -->
            <div class="flex border-b dark:border-gray-700 overflow-x-auto">
                <button onclick="switchTab('description')" id="tab-description" class="tab-btn flex-1 py-4 px-6 font-semibold text-blue-600 border-b-2 border-blue-600 whitespace-nowrap">
                    <i class="fas fa-align-left mr-2"></i>Description
                </button>
                <button onclick="switchTab('reviews')" id="tab-reviews" class="tab-btn flex-1 py-4 px-6 font-semibold text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white whitespace-nowrap">
                    <i class="fas fa-star mr-2"></i>Avis (<?= $product['rating_count'] ?>)
                </button>
            </div>

            <!-- Tab Content: Description -->
            <div id="content-description" class="tab-content p-6 md:p-8">
                <div class="prose dark:prose-invert max-w-none text-gray-600 dark:text-gray-300 leading-relaxed">
                    <?= nl2br(clean($product['description'] ?? 'Aucune description détaillée disponible pour ce produit.')) ?>
                </div>
            </div>

            <!-- Tab Content: Reviews -->
            <div id="content-reviews" class="tab-content p-6 md:p-8 hidden">
                <?php if (count($reviews) > 0): ?>
                    <div class="grid md:grid-cols-3 gap-8 mb-8">
                        <!-- Rating Summary -->
                        <div class="md:col-span-1">
                            <div class="text-center md:text-left">
                                <p class="text-5xl font-bold text-gray-800 dark:text-white"><?= number_format($product['rating_avg'], 1) ?></p>
                                <div class="flex justify-center md:justify-start my-2"><?= renderStars($product['rating_avg']) ?></div>
                                <p class="text-sm text-gray-500 dark:text-gray-400"><?= $product['rating_count'] ?> avis au total</p>
                            </div>
                            
                            <div class="mt-6 space-y-2">
                                <?php foreach ($ratingDistribution as $star => $count): 
                                    $percentage = $product['rating_count'] > 0 ? ($count / $product['rating_count']) * 100 : 0;
                                ?>
                                    <div class="flex items-center gap-3 text-sm">
                                        <span class="w-8 text-gray-600 dark:text-gray-300"><?= $star ?> <i class="fas fa-star text-yellow-400 text-xs"></i></span>
                                        <div class="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-yellow-400 rounded-full" style="width: <?= $percentage ?>%"></div>
                                        </div>
                                        <span class="w-8 text-right text-gray-500"><?= $count ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Reviews List -->
                        <div class="md:col-span-2 space-y-6">
                            <?php foreach ($reviews as $review): ?>
                                <div class="border-b dark:border-gray-700 pb-6 last:border-0">
                                    <div class="flex items-center gap-3 mb-2">
                                        <div class="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center font-bold text-gray-600 dark:text-gray-300">
                                            <?= strtoupper(substr($review['first_name'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <p class="font-semibold text-gray-800 dark:text-white"><?= clean($review['first_name'] . ' ' . $review['last_name']) ?></p>
                                            <p class="text-xs text-gray-500"><?= date('d/m/Y', strtotime($review['created_at'])) ?></p>
                                        </div>
                                    </div>
                                    <div class="mb-2"><?= renderStars($review['rating']) ?></div>
                                    <?php if ($review['title']): ?>
                                        <h4 class="font-bold text-gray-800 dark:text-white mb-1"><?= clean($review['title']) ?></h4>
                                    <?php endif; ?>
                                    <p class="text-gray-600 dark:text-gray-300 text-sm"><?= clean($review['comment']) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12">
                        <i class="fas fa-comment-slash text-4xl text-gray-300 mb-4"></i>
                        <p class="text-gray-500">Aucun avis pour le moment. Soyez le premier à donner votre avis !</p>
                    </div>
                <?php endif; ?>

                <!-- Add Review Form -->
                <?php if (isLoggedIn()): ?>
                    <div class="mt-8 pt-8 border-t dark:border-gray-700">
                        <h3 class="text-xl font-bold text-gray-800 dark:text-white mb-4">Laisser un avis</h3>
                        <form method="POST" action="" class="space-y-4 max-w-2xl">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Note</label>
                                <div class="flex gap-2 text-2xl text-gray-300 cursor-pointer" id="star-rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="far fa-star hover:text-yellow-400 transition" data-rating="<?= $i ?>" onclick="setRating(<?= $i ?>)"></i>
                                    <?php endfor; ?>
                                </div>
                                <input type="hidden" name="rating" id="rating-input" value="0" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Titre (optionnel)</label>
                                <input type="text" name="title" class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white" placeholder="Résumé de votre avis">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Commentaire</label>
                                <textarea name="comment" rows="4" required class="w-full px-4 py-2 border dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white" placeholder="Partagez votre expérience avec ce produit..."></textarea>
                            </div>
                            <button type="submit" name="submit_review" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition">
                                <i class="fas fa-paper-plane mr-2"></i>Publier l'avis
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="mt-8 pt-8 border-t dark:border-gray-700 text-center">
                        <p class="text-gray-500 mb-4">Vous devez être connecté pour laisser un avis.</p>
                        <a href="<?= BASE_URL ?>/login.php?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition">
                            Se connecter
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Related Products -->
<?php if (count($relatedProducts) > 0): ?>
<section class="py-8 md:py-12 bg-white dark:bg-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white mb-6">Produits similaires</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            <?php foreach ($relatedProducts as $relProduct): 
                $relImage = getProductImage($relProduct['id'], $pdo);
                $relDiscount = calculateDiscount($relProduct['price'], $relProduct['old_price']);
            ?>
                <div class="product-card bg-white dark:bg-gray-700 rounded-xl shadow-sm hover:shadow-2xl transition duration-300 overflow-hidden group border border-gray-100 dark:border-gray-600">
                    <div class="relative overflow-hidden">
                        <a href="<?= BASE_URL ?>/product.php?slug=<?= $relProduct['slug'] ?>">
                            <img src="<?= $relImage ?>" alt="<?= clean($relProduct['name']) ?>" class="w-full h-40 object-cover group-hover:scale-105 transition duration-500" loading="lazy">
                        </a>
                        <?php if ($relDiscount > 0): ?>
                            <span class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded font-semibold">-<?= $relDiscount ?>%</span>
                        <?php endif; ?>
                    </div>
                    <div class="p-3">
                        <a href="<?= BASE_URL ?>/product.php?slug=<?= $relProduct['slug'] ?>" class="block">
                            <h3 class="font-semibold text-gray-800 dark:text-white text-sm line-clamp-2 hover:text-blue-600 transition mb-2"><?= clean($relProduct['name']) ?></h3>
                        </a>
                        <div class="flex items-center justify-between">
                            <span class="text-base font-bold text-blue-600"><?= formatPrice($relProduct['price']) ?></span>
                            <button class="w-8 h-8 bg-blue-50 dark:bg-blue-900 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition" onclick="addToCart(<?= $relProduct['id'] ?>)">
                                <i class="fas fa-shopping-cart text-sm"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
// Image Gallery
function changeImage(src) {
    document.getElementById('mainImage').src = src;
    document.querySelectorAll('.thumbnail-btn').forEach(btn => {
        btn.classList.remove('border-blue-600');
        btn.classList.add('border-transparent');
    });
    event.currentTarget.classList.remove('border-transparent');
    event.currentTarget.classList.add('border-blue-600');
}

// Tabs
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(el => {
        el.classList.remove('text-blue-600', 'border-b-2', 'border-blue-600');
        el.classList.add('text-gray-500', 'dark:text-gray-400');
    });
    
    document.getElementById('content-' + tabName).classList.remove('hidden');
    const activeBtn = document.getElementById('tab-' + tabName);
    activeBtn.classList.remove('text-gray-500', 'dark:text-gray-400');
    activeBtn.classList.add('text-blue-600', 'border-b-2', 'border-blue-600');
}

// Star Rating for Review Form
function setRating(rating) {
    document.getElementById('rating-input').value = rating;
    const stars = document.querySelectorAll('#star-rating i');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.remove('far', 'text-gray-300');
            star.classList.add('fas', 'text-yellow-400');
        } else {
            star.classList.remove('fas', 'text-yellow-400');
            star.classList.add('far', 'text-gray-300');
        }
    });
}

// Contact Seller Modal (reused from shop.php logic)
function contactSeller(sellerId) {
    alert('Fonctionnalité de messagerie à implémenter pour le vendeur ID: ' + sellerId);
}
</script>

<?php 
// Afficher une alerte de succès si un avis vient d'être posté
if (isset($_GET['review_success'])): ?>
    <script>
        alert('Merci ! Votre avis a été publié avec succès.');
    </script>
<?php endif; ?>

<?php  ?>