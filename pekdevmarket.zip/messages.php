<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/header.php';





requireLogin();

$userId = $_SESSION['user_id'];

// Envoyer un message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    if (verifyCSRFToken($_POST[CSRF_TOKEN_NAME] ?? '')) {
        $toUserId = (int)$_POST['to_user_id'];
        $productId = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
        $message = clean($_POST['message'] ?? '');
        
        if (!empty($message) && $toUserId > 0 && $toUserId !== $userId) {
            $stmt = $pdo->prepare("
                INSERT INTO messages (from_user_id, to_user_id, product_id, message)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$userId, $toUserId, $productId, $message]);
            setFlash('success', 'Message envoyé');
        }
    }
    redirect($_SERVER['HTTP_REFERER'] ?? BASE_URL . '/messages.php');
}

// Conversations
$conversations = $pdo->prepare("
    SELECT 
        u.id as user_id, u.first_name, u.last_name,
        (SELECT message FROM messages 
         WHERE (from_user_id = ? AND to_user_id = u.id) 
            OR (from_user_id = u.id AND to_user_id = ?)
         ORDER BY created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM messages 
         WHERE (from_user_id = ? AND to_user_id = u.id) 
            OR (from_user_id = u.id AND to_user_id = ?)
         ORDER BY created_at DESC LIMIT 1) as last_time,
        (SELECT COUNT(*) FROM messages 
         WHERE from_user_id = u.id AND to_user_id = ? AND is_read = 0) as unread
    FROM users u
    WHERE u.id IN (
        SELECT DISTINCT CASE 
            WHEN from_user_id = ? THEN to_user_id 
            ELSE from_user_id 
        END
        FROM messages
        WHERE from_user_id = ? OR to_user_id = ?
    )
    ORDER BY last_time DESC
");
$conversations->execute([$userId, $userId, $userId, $userId, $userId, $userId, $userId, $userId]);
$conversations = $conversations->fetchAll();

// Conversation active
$activeUserId = (int)($_GET['user'] ?? 0);
$activeUser = null;
$messages = [];

if ($activeUserId > 0) {
    $stmt = $pdo->prepare("SELECT first_name, last_name, avatar FROM users WHERE id = ?");
    $stmt->execute([$activeUserId]);
    $activeUser = $stmt->fetch();
    
    if ($activeUser) {
        // Marquer comme lu
        $pdo->prepare("UPDATE messages SET is_read = 1 WHERE from_user_id = ? AND to_user_id = ?")
            ->execute([$activeUserId, $userId]);
        
        // Récupérer messages
        $stmt = $pdo->prepare("
            SELECT m.*, p.name as product_name, p.slug as product_slug
            FROM messages m
            LEFT JOIN products p ON m.product_id = p.id
            WHERE (m.from_user_id = ? AND m.to_user_id = ?)
               OR (m.from_user_id = ? AND m.to_user_id = ?)
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$userId, $activeUserId, $activeUserId, $userId]);
        $messages = $stmt->fetchAll();
    }
}

$pageTitle = 'Messages';

?>

<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white mb-6">
        <i class="fas fa-comments text-blue-600 mr-2"></i>Messages
    </h1>

    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden grid md:grid-cols-3 min-h-[600px]">
        <!-- Liste conversations -->
        <div class="md:col-span-1 border-r border-gray-200 dark:border-gray-700">
            <div class="p-4 border-b border-gray-200 dark:border-gray-700">
                <h2 class="font-bold text-gray-800 dark:text-white">Conversations</h2>
            </div>
            <div class="overflow-y-auto max-h-[500px]">
                <?php if (empty($conversations)): ?>
                    <div class="p-8 text-center text-gray-500">
                        <i class="fas fa-inbox text-4xl mb-2"></i>
                        <p class="text-sm">Aucune conversation</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($conversations as $conv): ?>
                        <a href="?user=<?= $conv['user_id'] ?>" 
                           class="flex items-center gap-3 p-4 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 <?= $activeUserId == $conv['user_id'] ? 'bg-blue-50 dark:bg-blue-900/20' : '' ?>">
                            <div class="relative">
                                <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                                    <?= strtoupper(substr($conv['first_name'], 0, 1)) ?>
                                </div>
                                <?php if ($conv['unread'] > 0): ?>
                                    <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full w-5 h-5 flex items-center justify-center">
                                        <?= $conv['unread'] ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="font-semibold text-sm text-gray-800 dark:text-white truncate">
                                    <?= clean($conv['first_name'] . ' ' . $conv['last_name']) ?>
                                </p>
                                <p class="text-xs text-gray-500 truncate"><?= clean($conv['last_message']) ?></p>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Zone messages -->
        <div class="md:col-span-2 flex flex-col">
            <?php if ($activeUser): ?>
                <!-- Header -->
                <div class="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                        <?= strtoupper(substr($activeUser['first_name'], 0, 1)) ?>
                    </div>
                    <div>
                        <p class="font-semibold text-gray-800 dark:text-white">
                            <?= clean($activeUser['first_name'] . ' ' . $activeUser['last_name']) ?>
                        </p>
                    </div>
                </div>

                <!-- Messages -->
                <div class="flex-1 overflow-y-auto p-4 space-y-3 max-h-[400px]">
                    <?php foreach ($messages as $msg): 
                        $isMe = $msg['from_user_id'] == $userId;
                    ?>
                        <div class="flex <?= $isMe ? 'justify-end' : 'justify-start' ?>">
                            <div class="max-w-[70%]">
                                <?php if ($msg['product_name']): ?>
                                    <a href="<?= BASE_URL ?>/product.php?slug=<?= $msg['product_slug'] ?>" 
                                       class="block mb-1 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-xs text-blue-600 hover:underline">
                                        <i class="fas fa-tag mr-1"></i><?= clean($msg['product_name']) ?>
                                    </a>
                                <?php endif; ?>
                                <div class="px-4 py-2 rounded-2xl <?= $isMe ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white rounded-bl-none' ?>">
                                    <p class="text-sm"><?= nl2br(clean($msg['message'])) ?></p>
                                </div>
                                <p class="text-[10px] text-gray-400 mt-1 <?= $isMe ? 'text-right' : '' ?>">
                                    <?= formatDate($msg['created_at'], 'relative') ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Formulaire -->
                <form method="POST" class="p-4 border-t border-gray-200 dark:border-gray-700">
                    <?= csrfField() ?>
                    <input type="hidden" name="to_user_id" value="<?= $activeUserId ?>">
                    <div class="flex gap-2">
                        <input type="text" name="message" required placeholder="Votre message..."
                               class="flex-1 px-4 py-2 border-2 border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white rounded-full focus:outline-none focus:border-blue-600">
                        <button type="submit" name="send_message" class="px-6 py-2 bg-blue-600 text-white rounded-full font-semibold hover:bg-blue-800">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="flex-1 flex items-center justify-center text-gray-400">
                    <div class="text-center">
                        <i class="fas fa-comments text-6xl mb-4"></i>
                        <p>Sélectionnez une conversation</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php  ?>