    <!-- Footer -->
    <footer class="bg-gray-900 text-white pt-12 pb-24 md:pb-8 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-8">
                <div class="col-span-2 md:col-span-1">
                    <div class="flex items-center gap-2 mb-4">
                        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                            <span class="text-white font-bold text-xl">P</span>
                        </div>
                        <div>
                            <span class="text-xl font-bold">PekDev</span>
                            <span class="text-orange-500 text-xs block">Market</span>
                        </div>
                    </div>
                    <p class="text-gray-400 text-sm mb-4">La plus grande marketplace du Burundi.</p>
                    <div class="flex gap-3">
                        <a href="#" class="w-9 h-9 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="w-9 h-9 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="w-9 h-9 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="w-9 h-9 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Liens rapides</h4>
                    <ul class="space-y-2 text-gray-400 text-sm">
                        <li><a href="<?= BASE_URL ?>/" class="hover:text-white">Accueil</a></li>
                        <li><a href="<?= BASE_URL ?>/products.php" class="hover:text-white">Produits</a></li>
                        <li><a href="<?= BASE_URL ?>/promotions.php" class="hover:text-white">Promotions</a></li>
                        <li><a href="<?= BASE_URL ?>/about.php" class="hover:text-white">À propos</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Aide</h4>
                    <ul class="space-y-2 text-gray-400 text-sm">
                        <li><a href="#" class="hover:text-white">Centre d'aide</a></li>
                        <li><a href="#" class="hover:text-white">Conditions d'utilisation</a></li>
                        <li><a href="#" class="hover:text-white">Confidentialité</a></li>
                        <li><a href="#" class="hover:text-white">FAQ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Contact</h4>
                    <ul class="space-y-3 text-gray-400 text-sm">
                        <li class="flex items-start gap-2">
                            <i class="fas fa-map-marker-alt mt-1 text-orange-500"></i>
                            <span>Bujumbura, Burundi</span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="fas fa-phone text-orange-500"></i>
                            <span>+257 123 456 789</span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="fas fa-envelope text-orange-500"></i>
                            <span>contact@pekdev.bi</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-gray-400 text-sm">&copy; 2026 PekDev Market. Tous droits réservés.</p>
                <div class="flex gap-4 text-gray-400 text-2xl">
                    <i class="fab fa-cc-visa hover:text-white"></i>
                    <i class="fab fa-cc-mastercard hover:text-white"></i>
                    <i class="fas fa-mobile-alt hover:text-white"></i>
                </div>
            </div>
        </div>
    </footer>

    <!-- Mobile Bottom Nav -->
    <nav class="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-40 shadow-2xl">
        <div class="grid grid-cols-5 py-2 px-2">
            <a href="<?= BASE_URL ?>/" class="flex flex-col items-center gap-1 text-blue-600 p-2">
                <i class="fas fa-home text-lg"></i>
                <span class="text-[10px]">Accueil</span>
            </a>
            <a href="<?= BASE_URL ?>/products.php" class="flex flex-col items-center gap-1 text-gray-500 dark:text-gray-400 p-2">
                <i class="fas fa-th-large text-lg"></i>
                <span class="text-[10px]">Catégories</span>
            </a>
            <a href="<?= BASE_URL ?>/sell.php" class="flex flex-col items-center gap-1 text-gray-500 dark:text-gray-400 relative p-2">
                <div class="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center -mt-6 shadow-lg">
                    <i class="fas fa-plus text-white text-xl"></i>
                </div>
                <span class="text-[10px] mt-1">Vendre</span>
            </a>
            <a href="<?= BASE_URL ?>/messages.php" class="flex flex-col items-center gap-1 text-gray-500 dark:text-gray-400 p-2">
                <i class="fas fa-comment-dots text-lg"></i>
                <span class="text-[10px]">Messages</span>
            </a>
            <a href="<?= BASE_URL ?>/profile.php" class="flex flex-col items-center gap-1 text-gray-500 dark:text-gray-400 p-2">
                <i class="fas fa-user text-lg"></i>
                <span class="text-[10px]">Profil</span>
            </a>
        </div>
    </nav>

    <script src="<?= ASSETS_URL ?>/js/main.js"></script>
</body>
</html>