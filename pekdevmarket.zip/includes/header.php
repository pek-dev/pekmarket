<?php
// Charger le bootstrap si pas déjà fait
if (!defined('BOOTSTRAP_LOADED')) {
    require_once __DIR__ . '/../config/bootstrap.php';
}

// Valeurs par défaut
if (!isset($pageTitle)) $pageTitle = 'PekDev Market';
if (!isset($pageDescription)) $pageDescription = 'La plus grande marketplace du Burundi';

$cartCount = 0;
$favoritesCount = 0;
$userName = '';
$userInitial = 'U';
$userEmail = '';
$userRole = '';

if (isLoggedIn()) {
    try {
        $cartCount = getCartCount($_SESSION['user_id'], $pdo);
        $favoritesCount = getFavoritesCount($_SESSION['user_id'], $pdo);
    } catch (Exception $e) {}
    
    if (isset($_SESSION['user_name']) && !empty($_SESSION['user_name'])) {
        $userName = $_SESSION['user_name'];
    } elseif (isset($_SESSION['user_first_name']) && isset($_SESSION['user_last_name'])) {
        $userName = $_SESSION['user_first_name'] . ' ' . $_SESSION['user_last_name'];
    } else {
        $userName = 'Utilisateur';
    }
    
    $userInitial = strtoupper(mb_substr($userName, 0, 1, 'UTF-8'));
    $userEmail = $_SESSION['user_email'] ?? '';
    $userRole = $_SESSION['user_role'] ?? 'customer';
}

try {
    $categoriesStmt = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 10");
    $categories = $categoriesStmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}

$currentFile = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="description" content="<?= clean($pageDescription) ?>">
    <meta name="theme-color" content="#1e40af">
    <meta name="base-url" content="<?= BASE_URL ?>">
    <meta name="csrf-token" content="<?= generateCSRFToken() ?>">
    <title><?= clean($pageTitle) ?> - PekDev Market</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        primaryDark: '#1e3a8a',
                        secondary: '#f97316',
                        secondaryDark: '#ea580c'
                    },
                    fontFamily: { sans: ['Inter', 'sans-serif'] }
                }
            }
        }
    </script>
    
    <!-- ============================================
         CSS INTÉGRÉ DIRECTEMENT (FONCTIONNE À 100%)
         ============================================ -->
    <style>
        /* Variables CSS */
        :root {
            --primary: #1e40af;
            --primary-dark: #1e3a8a;
            --secondary: #f97316;
            --secondary-dark: #ea580c;
        }
        
        /* Base */
        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { font-family: 'Inter', sans-serif; -webkit-font-smoothing: antialiased; }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse-soft {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        @keyframes bounce-soft {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        @keyframes shimmer {
            0% { background-position: -1000px 0; }
            100% { background-position: 1000px 0; }
        }
        
        .animate-fade-in { animation: fadeIn 0.6s ease-out forwards; }
        .animate-fade-in-up { animation: fadeIn 0.6s ease-out forwards; }
        .animate-slide-down { animation: slideDown 0.3s ease-out forwards; }
        .animate-pulse-soft { animation: pulse-soft 2s ease-in-out infinite; }
        .animate-bounce-soft { animation: bounce-soft 2s ease-in-out infinite; }
        .animate-float { animation: float 3s ease-in-out infinite; }
        
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        
        /* Product Cards */
        .product-card {
            transition: all 0.25s ease;
            position: relative;
            overflow: hidden;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 0.875rem;
            transition: all 0.25s ease;
            cursor: pointer;
            border: none;
            text-decoration: none;
        }
        .btn:active { transform: scale(0.98); }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
            color: white;
            box-shadow: 0 4px 14px 0 rgba(30, 64, 175, 0.39);
        }
        .btn-primary:hover {
            box-shadow: 0 6px 20px rgba(30, 64, 175, 0.23);
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
            color: white;
            box-shadow: 0 4px 14px 0 rgba(249, 115, 22, 0.39);
        }
        .btn-secondary:hover {
            box-shadow: 0 6px 20px rgba(249, 115, 22, 0.23);
            transform: translateY(-1px);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid #1e40af;
            color: #1e40af;
        }
        .btn-outline:hover {
            background: #1e40af;
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
        }
        
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.75rem; }
        .btn-lg { padding: 1rem 2rem; font-size: 1rem; }
        .btn-block { width: 100%; }
        
        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-primary { background: #dbeafe; color: #1e40af; }
        .badge-secondary { background: #ffedd5; color: #c2410c; }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            border: 1px solid #f3f4f6;
            transition: all 0.25s ease;
            overflow: hidden;
        }
        .dark .card { background: #1f2937; border-color: #374151; }
        .card:hover { box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); }
        
        .card-header { padding: 1.5rem; border-bottom: 1px solid #f3f4f6; }
        .dark .card-header { border-color: #374151; }
        .card-body { padding: 1.5rem; }
        .card-footer { padding: 1.5rem; border-top: 1px solid #f3f4f6; background: #f9fafb; }
        .dark .card-footer { border-color: #374151; background: #111827; }
        
        /* Forms */
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid #e5e7eb;
            border-radius: 0.75rem;
            font-size: 0.875rem;
            transition: all 0.15s ease;
            background: white;
        }
        .dark .form-input, .dark .form-select, .dark .form-textarea {
            background: #374151;
            border-color: #4b5563;
            color: white;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: #1e40af;
            box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
        }
        
        /* Scrollbar */
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 20px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; }
        
        /* Loading */
        .skeleton {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 1000px 100%;
            animation: shimmer 2s infinite linear;
            border-radius: 0.5rem;
        }
        
        .spinner {
            width: 2rem;
            height: 2rem;
            border: 3px solid #e5e7eb;
            border-top-color: #1e40af;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Modals */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.25s ease;
        }
        .modal-overlay.active { opacity: 1; visibility: visible; }
        .modal {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.25s ease;
        }
        .dark .modal { background: #1f2937; }
        .modal-overlay.active .modal { transform: scale(1); }
        
        /* Toasts */
        .toast-container {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .toast {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideDown 0.3s ease-out;
            border-left: 4px solid #1e40af;
        }
        .dark .toast { background: #1f2937; }
        .toast.success { border-left-color: #10b981; }
        .toast.error { border-left-color: #ef4444; }
        .toast.warning { border-left-color: #f59e0b; }
        
        /* Gradients */
        .bg-gradient-primary { background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%); }
        .bg-gradient-secondary { background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); }
        .bg-gradient-success { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .bg-gradient-danger { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); }
        
        .text-gradient {
            background: linear-gradient(135deg, #1e40af 0%, #f97316 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        /* Glass effect */
        .glass {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Shadows */
        .shadow-soft { box-shadow: 0 2px 15px -3px rgba(0, 0, 0, 0.07); }
        .shadow-colored { box-shadow: 0 10px 40px -10px rgba(30, 64, 175, 0.3); }
        
        /* Price */
        .price-tag {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e40af;
        }
        .price-tag .old-price {
            font-size: 0.875rem;
            color: #9ca3af;
            text-decoration: line-through;
            font-weight: 400;
            margin-left: 0.5rem;
        }
        
        /* Rating */
        .rating-stars {
            display: inline-flex;
            gap: 0.125rem;
            color: #fbbf24;
        }
        
        /* Avatar */
        .avatar {
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }
        
        /* Tabs */
        .tabs {
            display: flex;
            border-bottom: 2px solid #e5e7eb;
        }
        .dark .tabs { border-color: #374151; }
        .tab {
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            color: #6b7280;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            transition: all 0.15s ease;
        }
        .dark .tab { color: #9ca3af; }
        .tab:hover { color: #1e40af; }
        .tab.active { color: #1e40af; border-bottom-color: #1e40af; }
        
        /* Progress */
        .progress-bar {
            height: 0.5rem;
            background: #e5e7eb;
            border-radius: 9999px;
            overflow: hidden;
        }
        .dark .progress-bar { background: #374151; }
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #1e40af 0%, #3b82f6 100%);
            border-radius: 9999px;
            transition: width 0.35s ease;
        }
        
        /* Tooltip */
        .tooltip { position: relative; }
        .tooltip::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 0.5rem 0.75rem;
            background: #1f2937;
            color: white;
            font-size: 0.75rem;
            border-radius: 0.5rem;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.15s ease;
            pointer-events: none;
        }
        .tooltip:hover::after {
            opacity: 1;
            visibility: visible;
            bottom: calc(100% + 0.5rem);
        }
        
        /* Accessibility */
        :focus-visible {
            outline: 2px solid #1e40af;
            outline-offset: 2px;
        }
        
        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border-width: 0;
        }
        
        /* Mobile responsive */
        @media (max-width: 768px) {
            .product-card:hover { transform: none; }
            .btn { padding: 0.625rem 1.25rem; }
        }
        
        /* Print */
        @media print {
            .no-print, header, footer, .btn, .nav { display: none !important; }
            body { background: white; color: black; }
        }
        
        /* Discount & New badges */
        .discount-badge {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 0.375rem;
            font-size: 0.75rem;
            font-weight: 700;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            z-index: 10;
        }
        
        .new-badge {
            position: absolute;
            top: 0.5rem;
            right: 0.5rem;
            background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 0.375rem;
            font-size: 0.75rem;
            font-weight: 700;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            z-index: 10;
        }
        
        /* Dropdown animation */
        .dropdown-enter {
            animation: slideDown 0.2s ease-out forwards;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300 antialiased">

    <!-- TOP BANNER -->
    <div id="topBanner" class="bg-gradient-to-r from-blue-600 to-orange-600 text-white text-center py-2 text-xs sm:text-sm px-4 relative">
        <p class="flex items-center justify-center gap-2 flex-wrap">
            <i class="fas fa-truck text-yellow-300"></i>
            <span>Livraison gratuite à Bujumbura pour toute commande supérieure à <strong>100,000 FBu</strong> !</span>
            <button onclick="document.getElementById('topBanner').style.display='none'" class="ml-2 hover:bg-white/20 rounded-full p-1">
                <i class="fas fa-times"></i>
            </button>
        </p>
    </div>

    <!-- HEADER -->
    <header class="bg-white dark:bg-gray-800 shadow-md sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16 md:h-20">
                
                <button id="mobileMenuBtn" class="md:hidden p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                    <i class="fas fa-bars text-2xl"></i>
                </button>

                <a href="<?= BASE_URL ?>/" class="flex items-center gap-2 flex-shrink-0">
                    <div class="w-9 h-9 md:w-10 md:h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                        <span class="text-white font-bold text-lg md:text-xl">P</span>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-xl md:text-2xl font-bold text-blue-600 dark:text-white leading-none">PekDev</span>
                        <span class="text-[10px] md:text-xs text-orange-500 font-medium">Market</span>
                    </div>
                </a>

                <form action="<?= BASE_URL ?>/products.php" method="GET" class="hidden md:flex flex-1 max-w-2xl mx-8">
                    <div class="relative w-full">
                        <input type="text" name="q" 
                               class="w-full pl-12 pr-4 py-3 border-2 border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white rounded-full focus:outline-none focus:border-blue-600"
                               placeholder="Rechercher un produit..."
                               value="<?= isset($_GET['q']) ? clean($_GET['q']) : '' ?>">
                        <i class="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                </form>

                <button id="mobileSearchBtn" class="md:hidden p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                    <i class="fas fa-search text-xl"></i>
                </button>

                <div class="flex items-center gap-1 md:gap-3">
                    <button id="themeToggle" class="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                        <i class="fas fa-moon text-xl dark:hidden"></i>
                        <i class="fas fa-sun text-xl hidden dark:block text-yellow-400"></i>
                    </button>
                    
                    <?php if (isLoggedIn()): ?>
                        <a href="<?= BASE_URL ?>/favorites.php" class="relative p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg hidden sm:block">
                            <i class="far fa-heart text-xl"></i>
                            <?php if ($favoritesCount > 0): ?>
                                <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center"><?= $favoritesCount ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                    
                    <a href="<?= BASE_URL ?>/cart.php" class="relative p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                        <i class="fas fa-shopping-cart text-xl"></i>
                        <?php if ($cartCount > 0): ?>
                            <span class="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] rounded-full w-5 h-5 flex items-center justify-center font-bold"><?= $cartCount ?></span>
                        <?php endif; ?>
                    </a>

                    <?php if (isLoggedIn()): ?>
                        <div class="relative">
                            <button onclick="document.getElementById('userMenu').classList.toggle('hidden')" class="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                                <div class="w-8 h-8 bg-gradient-to-br from-blue-600 to-orange-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                                    <?= $userInitial ?>
                                </div>
                                <span class="hidden md:inline text-sm font-medium text-gray-700 dark:text-gray-200"><?= clean($userName) ?></span>
                            </button>
                            <div id="userMenu" class="hidden absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 py-2 z-50 dropdown-enter">
                                <div class="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                                    <p class="text-sm font-semibold text-gray-800 dark:text-white"><?= clean($userName) ?></p>
                                    <p class="text-xs text-gray-500 truncate"><?= clean($userEmail) ?></p>
                                </div>
                                <a href="<?= BASE_URL ?>/profile.php" class="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">
                                    <i class="fas fa-user w-4"></i> Mon profil
                                </a>
                                <a href="<?= BASE_URL ?>/orders.php" class="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">
                                    <i class="fas fa-box w-4"></i> Mes commandes
                                </a>
                                <?php if ($userRole === 'seller' || $userRole === 'admin'): ?>
                                    <a href="<?= BASE_URL ?>/dashboard/<?= $userRole ?>.php" class="flex items-center gap-3 px-4 py-2 text-sm text-blue-600 font-semibold hover:bg-blue-600/10">
                                        <i class="fas fa-chart-line w-4"></i> Dashboard
                                    </a>
                                <?php endif; ?>
                                <div class="border-t border-gray-200 dark:border-gray-700 mt-2 pt-2">
                                    <a href="<?= BASE_URL ?>/logout.php" class="flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20">
                                        <i class="fas fa-sign-out-alt w-4"></i> Déconnexion
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>/login.php" class="hidden md:block px-4 py-2 border-2 border-blue-600 text-blue-600 dark:text-white rounded-lg hover:bg-blue-600 hover:text-white font-semibold text-sm">
                            Connexion
                        </a>
                        <a href="<?= BASE_URL ?>/register.php" class="hidden md:block px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-semibold text-sm">
                            Inscription
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <div id="mobileSearch" class="hidden md:hidden pb-4">
                <form action="<?= BASE_URL ?>/products.php" method="GET">
                    <div class="relative">
                        <input type="text" name="q" class="w-full pl-12 pr-4 py-3 border-2 border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white rounded-full" placeholder="Rechercher...">
                        <i class="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                </form>
            </div>

            <nav class="hidden md:flex items-center gap-6 py-3 border-t border-gray-100 dark:border-gray-700">
                <a href="<?= BASE_URL ?>/" class="text-blue-600 font-semibold flex items-center gap-1">
                    <i class="fas fa-home"></i> Accueil
                </a>
                <div class="relative group">
                    <button class="text-gray-600 dark:text-gray-300 hover:text-blue-600 flex items-center gap-1 font-medium">
                        Catégories <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                    <div class="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                        <?php foreach ($categories as $cat): ?>
                            <a href="<?= BASE_URL ?>/category.php?slug=<?= $cat['slug'] ?>" class="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">
                                <i class="<?= $cat['icon'] ?> text-<?= $cat['color'] ?>-500 w-5"></i>
                                <span><?= clean($cat['name']) ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <a href="<?= BASE_URL ?>/products.php" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 font-medium">Produits</a>
                <a href="<?= BASE_URL ?>/promotions.php" class="text-gray-600 dark:text-gray-300 hover:text-blue-600 font-medium">Promotions</a>
            </nav>
        </div>

        <div id="mobileMenu" class="hidden md:hidden bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 absolute w-full shadow-xl z-50">
            <div class="px-4 py-4 space-y-2 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <a href="<?= BASE_URL ?>/" class="block py-3 px-4 text-blue-600 font-semibold bg-blue-50 dark:bg-blue-900/20 rounded-lg">Accueil</a>
                <?php foreach ($categories as $cat): ?>
                    <a href="<?= BASE_URL ?>/category.php?slug=<?= $cat['slug'] ?>" class="flex items-center gap-3 py-2 px-4 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg">
                        <i class="<?= $cat['icon'] ?> text-<?= $cat['color'] ?>-500 w-5"></i>
                        <?= clean($cat['name']) ?>
                    </a>
                <?php endforeach; ?>
                
                <?php if (!isLoggedIn()): ?>
                    <div class="pt-4 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                        <a href="<?= BASE_URL ?>/login.php" class="flex-1 py-3 border-2 border-blue-600 text-blue-600 rounded-lg font-semibold text-center">Connexion</a>
                        <a href="<?= BASE_URL ?>/register.php" class="flex-1 py-3 bg-orange-500 text-white rounded-lg font-semibold text-center">Inscription</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div id="flashContainer"><?php if (function_exists('displayFlash')) displayFlash(); ?></div>

    <script>
        // Dark mode
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                document.documentElement.classList.toggle('dark');
                localStorage.setItem('theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
            });
            if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                document.documentElement.classList.add('dark');
            }
        }

        // Mobile menu
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }

        // Mobile search
        const mobileSearchBtn = document.getElementById('mobileSearchBtn');
        const mobileSearch = document.getElementById('mobileSearch');
        if (mobileSearchBtn && mobileSearch) {
            mobileSearchBtn.addEventListener('click', () => {
                mobileSearch.classList.toggle('hidden');
            });
        }

        // Close user menu on outside click
        document.addEventListener('click', (e) => {
            const userMenu = document.getElementById('userMenu');
            if (userMenu && !e.target.closest('[onclick*="userMenu"]') && !e.target.closest('#userMenu')) {
                userMenu.classList.add('hidden');
            }
        });
    </script>