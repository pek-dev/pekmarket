<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/includes/header.php';




// Si déjà connecté, rediriger selon le rôle
if (isLoggedIn()) {
    header('Location: ' . redirectByRole());
    exit;
}

$errors = [];
$email = '';
$remember = false;

// Générer un token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Traitement de la connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Token de sécurité invalide. Veuillez réessayer.";
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);
        
        // Rate limiting simple
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = 0;
            $_SESSION['login_attempts_time'] = time();
        }
        
        if ($_SESSION['login_attempts'] >= 5 && (time() - $_SESSION['login_attempts_time']) < 900) {
            $errors[] = "Trop de tentatives. Veuillez réessayer dans 15 minutes.";
        } else {
            // Validation
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Adresse email invalide.";
            }
            if (empty($password)) {
                $errors[] = "Le mot de passe est requis.";
            }
            
            if (count($errors) === 0) {
                // Récupérer l'utilisateur
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                
                if ($user && password_verify($password, $user['password'])) {
                    // Connexion réussie
                    $_SESSION['login_attempts'] = 0;
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_first_name'] = $user['first_name'];
                    $_SESSION['user_last_name'] = $user['last_name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                    $_SESSION['user_avatar'] = $user['avatar'] ?? null;
                    
                    // Mettre à jour la dernière connexion
                    $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
                    
                    // "Se souvenir de moi" (cookie 30 jours)
                    if ($remember) {
                        $token = bin2hex(random_bytes(32));
                        setcookie('remember_token', $token, time() + (30 * 86400), '/', '', false, true);
                        setcookie('remember_email', $email, time() + (30 * 86400), '/', '', false, true);
                    }
                    
                    // Redirection
                    $redirect = $_SESSION['redirect_after_login'] ?? redirectByRole();
                    unset($_SESSION['redirect_after_login']);
                    header('Location: ' . $redirect);
                    exit;
                } else {
                    $_SESSION['login_attempts']++;
                    $errors[] = "Email ou mot de passe incorrect.";
                }
            }
        }
    }
}

// Récupérer l'email depuis le cookie "Se souvenir de moi"
if (isset($_COOKIE['remember_email']) && empty($email)) {
    $email = $_COOKIE['remember_email'];
}

$pageTitle = 'Connexion - PekDev Market';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        primaryDark: '#1e3a8a',
                        secondary: '#f97316',
                        secondaryDark: '#ea580c'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in { animation: fadeIn 0.6s ease-out; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="min-h-screen flex">
        
        <!-- Left Side: Branding (hidden on mobile) -->
        <div class="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-600 via-blue-700 to-primaryDark relative overflow-hidden">
            <div class="absolute top-20 left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div class="absolute bottom-20 right-20 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl"></div>
            
            <div class="relative z-10 flex flex-col justify-between p-12 text-white w-full">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
                        <i class="fas fa-store text-blue-600 text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold">PekDev Market</h1>
                        <p class="text-sm text-blue-200">La marketplace du Burundi</p>
                    </div>
                </div>
                
                <div class="space-y-8">
                    <div>
                        <h2 class="text-4xl font-bold mb-4 leading-tight">
                            Bienvenue sur<br>
                            <span class="text-orange-500">PekDev Market</span>
                        </h2>
                        <p class="text-blue-100 text-lg max-w-md">
                            La plus grande marketplace du Burundi. Achetez et vendez facilement près de chez vous.
                        </p>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                                <i class="fas fa-shield-alt text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold">Paiement sécurisé</h3>
                                <p class="text-sm text-blue-200">Transactions 100% protégées</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                                <i class="fas fa-truck text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold">Livraison rapide</h3>
                                <p class="text-sm text-blue-200">Dans tout le Burundi</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                                <i class="fas fa-headset text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold">Support 24/7</h3>
                                <p class="text-sm text-blue-200">Assistance à tout moment</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-sm text-blue-200">
                    © <?= date('Y') ?> PekDev Market. Tous droits réservés.
                </div>
            </div>
        </div>

        <!-- Right Side: Login Form -->
        <div class="w-full lg:w-1/2 flex items-center justify-center p-6 md:p-12">
            <div class="w-full max-w-md animate-fade-in">
                
                <!-- Mobile Logo -->
                <div class="lg:hidden flex items-center gap-3 mb-8 justify-center">
                    <div class="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                        <i class="fas fa-store text-white text-2xl"></i>
                    </div>
                    <h1 class="text-2xl font-bold text-gray-800">PekDev Market</h1>
                </div>
                
                <!-- Header -->
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800 mb-2">Bon retour ! 👋</h2>
                    <p class="text-gray-500">Connectez-vous à votre compte pour continuer</p>
                </div>

                <!-- Errors -->
                <?php if (count($errors) > 0): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-start gap-3">
                        <i class="fas fa-exclamation-circle mt-1"></i>
                        <div class="flex-1">
                            <?php foreach ($errors as $error): ?>
                                <p class="text-sm"><?= clean($error) ?></p>
                            <?php endforeach; ?>
                        </div>
                        <button onclick="this.parentElement.remove()" class="text-red-500 hover:text-red-700">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                <?php endif; ?>

                <!-- Success message -->
                <?php if (isset($_GET['registered'])): ?>
                    <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-6 flex items-start gap-3">
                        <i class="fas fa-check-circle mt-1"></i>
                        <p class="text-sm">Inscription réussie ! Vous pouvez maintenant vous connecter.</p>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['logout'])): ?>
                    <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-xl mb-6 flex items-start gap-3">
                        <i class="fas fa-info-circle mt-1"></i>
                        <p class="text-sm">Vous avez été déconnecté avec succès.</p>
                    </div>
                <?php endif; ?>

                <!-- Login Form -->
                <form method="POST" action="" class="space-y-5">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    
                    <!-- Email -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Adresse email</label>
                        <div class="relative">
                            <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <input type="email" name="email" value="<?= clean($email) ?>" required
                                   class="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-600 transition"
                                   placeholder="exemple@email.com">
                        </div>
                    </div>

                    <!-- Password -->
                    <div>
                        <div class="flex justify-between items-center mb-2">
                            <label class="block text-sm font-semibold text-gray-700">Mot de passe</label>
                            <a href="forgot-password.php" class="text-sm text-blue-600 hover:text-blue-800 font-medium">
                                Mot de passe oublié ?
                            </a>
                        </div>
                        <div class="relative">
                            <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" name="password" id="password" required
                                   class="w-full pl-11 pr-12 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-600 transition"
                                   placeholder="••••••••">
                            <button type="button" onclick="togglePassword()" 
                                    class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                                <i class="fas fa-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Remember me -->
                    <div class="flex items-center justify-between">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="remember" <?= $remember ? 'checked' : '' ?>
                                   class="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500">
                            <span class="text-sm text-gray-600">Se souvenir de moi</span>
                        </label>
                    </div>

                    <!-- Submit -->
                    <button type="submit" 
                            class="w-full bg-blue-600 text-white py-3.5 rounded-xl font-semibold hover:bg-blue-800 transition shadow-lg shadow-primary/30 flex items-center justify-center gap-2">
                        <i class="fas fa-sign-in-alt"></i>
                        Se connecter
                    </button>
                </form>

                <!-- Divider -->
                <div class="relative my-6">
                    <div class="absolute inset-0 flex items-center">
                        <div class="w-full border-t border-gray-300"></div>
                    </div>
                    <div class="relative flex justify-center text-sm">
                        <span class="px-4 bg-gray-50 text-gray-500">ou</span>
                    </div>
                </div>

                <!-- Register link -->
                <div class="text-center">
                    <p class="text-gray-600 mb-4">Pas encore de compte ?</p>
                    <a href="register.php" 
                       class="block w-full bg-orange-500 text-white py-3.5 rounded-xl font-semibold hover:bg-orange-600 transition shadow-lg shadow-secondary/30 flex items-center justify-center gap-2">
                        <i class="fas fa-user-plus"></i>
                        Créer un compte
                    </a>
                </div>

                <!-- Back to home -->
                <div class="text-center mt-6">
                    <a href="index.php" class="text-sm text-gray-500 hover:text-blue-600 transition">
                        <i class="fas fa-arrow-left mr-1"></i> Retour à l'accueil
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>