<?php
require_once __DIR__ . '/config/bootstrap.php';

require_once __DIR__ . '/includes/header.php';




// Rediriger si non connecté
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = BASE_URL . '/cart.php';
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$messageType = 'success';

// Traitement des actions (Mise à jour / Suppression)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cart_id = intval($_POST['cart_id'] ?? 0);
    
    if ($action === 'update' && $cart_id > 0) {
        $qty = max(1, intval($_POST['quantity'] ?? 1));
        $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$qty, $cart_id, $user_id]);
        $message = 'Quantité mise à jour avec succès.';
    } 
    elseif ($action === 'delete' && $cart_id > 0) {
        $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
        $stmt->execute([$cart_id, $user_id]);
        $message = 'Article supprimé du panier.';
    }
}

// Récupérer les articles du panier
$cartStmt = $pdo->prepare("
    SELECT c.id as cart_id, c.quantity, 
           p.id as product_id, p.name, p.slug, p.price, p.old_price, p.stock, p.seller_id,
           u.first_name as seller_first, u.last_name as seller_last,
           pi.image_path
    FROM cart c
    JOIN products p ON c.product_id = p.id
    LEFT JOIN users u ON p.seller_id = u.id
    LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ? AND p.is_active = 1
    ORDER BY c.created_at DESC
");
$cartStmt->execute([$user_id]);
$cartItems = $cartStmt->fetchAll();

// Calculs
$subtotal = 0;
$totalItems = 0;
foreach ($cartItems as $item) {
    $itemTotal = $item['price'] * $item['quantity'];
    $subtotal += $itemTotal;
    $totalItems += $item['quantity'];
}

// Frais de livraison (estimés, à adapter selon votre logique)
$shippingCost = $subtotal > 100000 ? 0 : 5000; 
$total = $subtotal + $shippingCost;

$pageTitle = 'Mon Panier';

?>

<!-- Header -->
<section class="bg-gray-50 dark:bg-gray-900 py-8 border-b dark:border-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="text-sm text-gray-500 dark:text-gray-400 mb-2">
            <a href="<?= BASE_URL ?>" class="hover:text-blue-600 transition">Accueil</a>
            <i class="fas fa-chevron-right text-xs mx-2"></i>
            <span class="text-gray-800 dark:text-white font-medium">Panier</span>
        </nav>
        <h1 class="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white">Mon Panier</h1>
        <p class="text-gray-500 dark:text-gray-400"><?= $totalItems ?> article<?= $totalItems > 1 ? 's' : '' ?> dans votre panier</p>
    </div>
</section>

<!-- Main Content -->
<section class="py-8 md:py-12 bg-gray-50 dark:bg-gray-900 min-h-screen">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <?php if ($message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 flex items-center justify-between">
                <span><i class="fas fa-check-circle mr-2"></i><?= clean($message) ?></span>
                <button onclick="this.parentElement.remove()" class="text-green-700 hover:text-green-900"><i class="fas fa-times"></i></button>
            </div>
        <?php endif; ?>

        <?php if (count($cartItems) > 0): ?>
            <div class="grid lg:grid-cols-3 gap-8">
                
                <!-- Cart Items List -->
                <div class="lg:col-span-2 space-y-4">
                    <?php foreach ($cartItems as $item): 
                        $discount = calculateDiscount($item['price'], $item['old_price']);
                    ?>
                        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 md:p-6 flex flex-col sm:flex-row gap-4 border border-gray-100 dark:border-gray-700">
                            <!-- Image -->
                            <div class="w-full sm:w-32 h-32 flex-shrink-0">
                                <a href="<?= BASE_URL ?>/product.php?slug=<?= $item['slug'] ?>">
                                    <img src="<?= $item['image_path'] ?: 'https://via.placeholder.com/150' ?>" 
                                         alt="<?= clean($item['name']) ?>" 
                                         class="w-full h-full object-cover rounded-lg">
                                </a>
                            </div>
                            
                            <!-- Details -->
                            <div class="flex-1 flex flex-col justify-between">
                                <div>
                                    <div class="flex justify-between items-start mb-2">
                                        <a href="<?= BASE_URL ?>/product.php?slug=<?= $item['slug'] ?>" class="font-bold text-gray-800 dark:text-white hover:text-blue-600 transition line-clamp-2">
                                            <?= clean($item['name']) ?>
                                        </a>
                                        <form method="POST" action="" class="ml-2">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                                            <button type="submit" class="text-gray-400 hover:text-red-500 transition" title="Supprimer" onclick="return confirm('Supprimer cet article ?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                    
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-2">
                                        <i class="fas fa-user mr-1"></i> Vendu par <?= clean($item['seller_first'] . ' ' . $item['seller_last']) ?>
                                    </p>
                                    
                                    <div class="flex items-center gap-2 mb-2">
                                        <span class="text-lg font-bold text-blue-600"><?= formatPrice($item['price']) ?></span>
                                        <?php if ($item['old_price']): ?>
                                            <span class="text-sm text-gray-400 line-through"><?= formatPrice($item['old_price']) ?></span>
                                            <span class="bg-red-100 text-red-600 text-xs px-2 py-0.5 rounded font-semibold">-<?= $discount ?>%</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Quantity & Subtotal -->
                                <div class="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                                    <form method="POST" action="" class="flex items-center border dark:border-gray-600 rounded-lg overflow-hidden">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                                        
                                        <button type="submit" name="quantity" value="<?= max(1, $item['quantity'] - 1) ?>" 
                                                class="px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition" <?= $item['quantity'] <= 1 ? 'disabled' : '' ?>>
                                            <i class="fas fa-minus text-xs"></i>
                                        </button>
                                        
                                        <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>" 
                                               class="w-12 text-center border-0 dark:bg-gray-800 dark:text-white focus:ring-0 p-2" onchange="this.form.submit()">
                                        
                                        <button type="submit" name="quantity" value="<?= min($item['stock'], $item['quantity'] + 1) ?>" 
                                                class="px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition" <?= $item['quantity'] >= $item['stock'] ? 'disabled' : '' ?>>
                                            <i class="fas fa-plus text-xs"></i>
                                        </button>
                                    </form>
                                    
                                    <div class="text-right">
                                        <p class="text-xs text-gray-500 dark:text-gray-400">Sous-total</p>
                                        <p class="text-lg font-bold text-gray-800 dark:text-white"><?= formatPrice($item['price'] * $item['quantity']) ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="flex justify-between items-center pt-4">
                        <a href="<?= BASE_URL ?>/products.php" class="text-blue-600 hover:text-orange-500 font-semibold flex items-center gap-2">
                            <i class="fas fa-arrow-left"></i> Continuer mes achats
                        </a>
                        <form method="POST" action="<?= BASE_URL ?>/cart-clear.php" onsubmit="return confirm('Vider tout le panier ?');">
                            <button type="submit" class="text-red-500 hover:text-red-700 font-semibold flex items-center gap-2">
                                <i class="fas fa-trash"></i> Vider le panier
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Order Summary -->
                <div class="lg:col-span-1">
                    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 sticky top-4 border border-gray-100 dark:border-gray-700">
                        <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-6">Résumé de la commande</h2>
                        
                        <div class="space-y-3 mb-6">
                            <div class="flex justify-between text-gray-600 dark:text-gray-300">
                                <span>Sous-total (<?= $totalItems ?> articles)</span>
                                <span class="font-semibold"><?= formatPrice($subtotal) ?></span>
                            </div>
                            <div class="flex justify-between text-gray-600 dark:text-gray-300">
                                <span>Livraison</span>
                                <span class="font-semibold <?= $shippingCost == 0 ? 'text-green-500' : '' ?>">
                                    <?= $shippingCost == 0 ? 'Gratuite' : formatPrice($shippingCost) ?>
                                </span>
                            </div>
                            <?php if ($shippingCost > 0): ?>
                                <p class="text-xs text-gray-500 bg-blue-50 dark:bg-blue-900/20 p-2 rounded">
                                    <i class="fas fa-info-circle mr-1"></i> Livraison gratuite à partir de 100 000 FBu
                                </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="border-t dark:border-gray-700 pt-4 mb-6">
                            <div class="flex justify-between items-center">
                                <span class="text-lg font-bold text-gray-800 dark:text-white">Total</span>
                                <span class="text-2xl font-bold text-blue-600"><?= formatPrice($total) ?></span>
                            </div>
                        </div>
                        
                        <a href="<?= BASE_URL ?>/checkout.php" class="block w-full bg-blue-600 text-white text-center py-3 rounded-xl font-semibold hover:bg-blue-800 transition shadow-lg shadow-primary/30 mb-3">
                            <i class="fas fa-lock mr-2"></i>Passer la commande
                        </a>
                        
                        <div class="flex justify-center gap-4 text-2xl text-gray-400 mt-4">
                            <i class="fab fa-cc-visa hover:text-blue-600 transition"></i>
                            <i class="fab fa-cc-mastercard hover:text-red-600 transition"></i>
                            <i class="fas fa-mobile-alt hover:text-green-600 transition" title="Mobile Money"></i>
                            <i class="fas fa-money-bill-wave hover:text-green-600 transition" title="Cash"></i>
                        </div>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <!-- Empty Cart -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-12 text-center max-w-2xl mx-auto">
                <div class="w-24 h-24 mx-auto bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mb-6">
                    <i class="fas fa-shopping-cart text-4xl text-gray-400"></i>
                </div>
                <h2 class="text-2xl font-bold text-gray-800 dark:text-white mb-2">Votre panier est vide</h2>
                <p class="text-gray-500 dark:text-gray-400 mb-8">
                    Vous n'avez aucun article dans votre panier. Parcourez notre catalogue pour trouver des produits qui vous intéressent.
                </p>
                <a href="<?= BASE_URL ?>/products.php" class="inline-block bg-blue-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-blue-800 transition shadow-lg">
                    <i class="fas fa-shopping-bag mr-2"></i>Découvrir les produits
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php  ?>